import process from 'node:process';
import { describe, it, strict } from 'poku';
import { createConnection } from '../../common.test.mjs';

let exceptionCount = 0;

process.on('uncaughtException', () => {
  exceptionCount++;
});

await describe('Error Events', async () => {
  await it('should handle error events without uncaught exceptions', async () => {
    let callCount = 0;

    const connection1 = createConnection({
      password: 'lol',
    });

    const connection2 = createConnection({
      password: 'lol',
    });

    await new Promise<void>((resolve) => {
      // error will NOT bubble up to process level if `on` is used
      connection1.on('error', () => {
        callCount++;
        if (callCount === 2) resolve();
      });

      // error will bubble up to process level if `once` is used
      connection2.once('error', () => {
        callCount++;
        if (callCount === 2) resolve();
      });
    });

    strict.equal(callCount, 2);
    strict.equal(exceptionCount, 0);
  });
});
