import type { RowDataPacket } from '../../../index.js';
import { describe, it, strict } from 'poku';
import { createConnection } from '../../common.test.mjs';

await describe('Datetime', async () => {
  const connection = createConnection();
  const connection1 = createConnection({ dateStrings: true });
  const connection2 = createConnection({ dateStrings: ['DATE'] });
  const connectionZ = createConnection({ timezone: 'Z' });
  const connection0930 = createConnection({ timezone: '+09:30' });

  let rows: RowDataPacket[],
    rowsZ: RowDataPacket[],
    rows0930: RowDataPacket[],
    rows1: RowDataPacket[],
    rows1Z: RowDataPacket[],
    rows10930: RowDataPacket[],
    rows2: RowDataPacket[],
    rows3: RowDataPacket[],
    rows4: RowDataPacket[],
    rows5: RowDataPacket[],
    rows6: RowDataPacket[],
    rows7: RowDataPacket[],
    rows8: RowDataPacket[];

  const date = new Date('1990-01-01 08:15:11 UTC');
  const datetime = new Date('2010-12-10 14:12:09.019473');

  const date1 = new Date('2000-03-03 08:15:11 UTC');
  const date2 = '2010-12-10 14:12:09.019473';
  const date3 = null;
  const date4 = '2010-12-10 14:12:09.123456';
  const date5 = '2010-12-10 14:12:09.019';
  const date6 = '2024-11-10 00:00:00';

  function adjustTZ(d: Date, offset?: number) {
    if (offset === undefined) {
      offset = d.getTimezoneOffset();
    }
    return new Date(d.getTime() - offset * 60000);
  }

  function toMidnight(d: Date, offset?: number) {
    const t = d.getTime();
    if (offset === undefined) {
      offset = d.getTimezoneOffset();
    }
    return new Date(t - (t % (24 * 60 * 60 * 1000)) + offset * 60000);
  }

  function formatUTCDate(d: Date) {
    return d.toISOString().substring(0, 10);
  }

  function formatUTCDateTime(d: Date, precision?: number) {
    const raw = d.toISOString().replace('T', ' ');
    if (precision === undefined) {
      precision = 0;
    }
    return precision <= 3
      ? raw.substring(0, 19 + (precision && 1) + precision)
      : raw.substring(0, 23) + '0'.repeat(precision - 3);
  }

  connection.query(
    'CREATE TEMPORARY TABLE t (d1 DATE, d2 DATETIME(3), d3 DATETIME(6))'
  );
  connection.query('INSERT INTO t set d1=?, d2=?, d3=?', [
    date,
    datetime,
    datetime,
  ]);

  connection1.query(
    'CREATE TEMPORARY TABLE t (d1 DATE, d2 TIMESTAMP, d3 DATETIME, d4 DATETIME, d5 DATETIME(6), d6 DATETIME(3), d7 DATETIME)'
  );
  connection1.query(
    'INSERT INTO t set d1=?, d2=?, d3=?, d4=?, d5=?, d6=?, d7=?',
    [date, date1, date2, date3, date4, date5, date6]
  );

  connection2.query(
    'CREATE TEMPORARY TABLE t (d1 DATE, d2 TIMESTAMP, d3 DATETIME, d4 DATETIME, d5 DATETIME(6), d6 DATETIME(3), d7 DATETIME)'
  );
  connection2.query(
    'INSERT INTO t set d1=?, d2=?, d3=?, d4=?, d5=?, d6=?, d7=?',
    [date, date1, date2, date3, date4, date5, date6]
  );

  connectionZ.query(
    'CREATE TEMPORARY TABLE t (d1 DATE, d2 DATETIME(3), d3 DATETIME(6))'
  );
  connectionZ.query("set time_zone = '+00:00'");
  connectionZ.query('INSERT INTO t set d1=?, d2=?, d3=?', [
    date,
    datetime,
    datetime,
  ]);

  connection0930.query(
    'CREATE TEMPORARY TABLE t (d1 DATE, d2 DATETIME(3), d3 DATETIME(6))'
  );
  connection0930.query("set time_zone = '+09:30'");
  connection0930.query('INSERT INTO t set d1=?, d2=?, d3=?', [
    date,
    datetime,
    datetime,
  ]);

  const dateAsStringExpected = [
    {
      d1: formatUTCDate(adjustTZ(date)),
      d2: formatUTCDateTime(adjustTZ(date1)),
      d3: date2.substring(0, 19),
      d4: date3,
      d5: date4,
      d6: date5,
      d7: date6,
    },
  ];

  await it('should handle datetime values across timezones and formats', async () => {
    await new Promise<void>((resolve, reject) => {
      let ended = 0;
      const TOTAL = 5;
      function checkDone() {
        ended++;
        if (ended === TOTAL) resolve();
      }

      connection.execute<RowDataPacket[]>(
        'select from_unixtime(?) t',
        [(+date).valueOf() / 1000],
        (err, _rows) => {
          if (err) return reject(err);
          rows = _rows;
        }
      );

      connectionZ.execute<RowDataPacket[]>(
        'select from_unixtime(?) t',
        [(+date).valueOf() / 1000],
        (err, _rows) => {
          if (err) return reject(err);
          rowsZ = _rows;
        }
      );

      connection0930.execute<RowDataPacket[]>(
        'select from_unixtime(?) t',
        [(+date).valueOf() / 1000],
        (err, _rows) => {
          if (err) return reject(err);
          rows0930 = _rows;
        }
      );

      connection.query<RowDataPacket[]>(
        'select from_unixtime(631152000) t',
        (err, _rows) => {
          if (err) return reject(err);
          rows1 = _rows;
        }
      );

      connectionZ.query<RowDataPacket[]>(
        'select from_unixtime(631152000) t',
        (err, _rows) => {
          if (err) return reject(err);
          rows1Z = _rows;
        }
      );

      connection0930.query<RowDataPacket[]>(
        'select from_unixtime(631152000) t',
        (err, _rows) => {
          if (err) return reject(err);
          rows10930 = _rows;
        }
      );

      connection.query<RowDataPacket[]>(
        'select *, cast(d1 as char) as d4, cast(d2 as char) as d5, cast(d3 as char) as d6 from t',
        (err, _rows) => {
          if (err) return reject(err);
          rows2 = _rows;
          checkDone();
        }
      );

      connectionZ.execute<RowDataPacket[]>(
        'select *, cast(d1 as char) as d4, cast(d2 as char) as d5, cast(d3 as char) as d6 from t',
        (err, _rows) => {
          if (err) return reject(err);
          rows3 = _rows;
          checkDone();
        }
      );

      connection1.query<RowDataPacket[]>('select * from t', (err, _rows) => {
        if (err) return reject(err);
        rows4 = _rows;
      });

      connection1.execute<RowDataPacket[]>('select * from t', (err, _rows) => {
        if (err) return reject(err);
        rows5 = _rows;
      });

      connection1.execute<RowDataPacket[]>(
        'select * from t where d6 = ?',
        [new Date(date5)],
        (err, _rows) => {
          if (err) return reject(err);
          rows6 = _rows;
          checkDone();
        }
      );

      connection2.execute<RowDataPacket[]>('select * from t', (err, _rows) => {
        if (err) return reject(err);
        rows8 = _rows;
        checkDone();
      });

      connection0930.execute<RowDataPacket[]>(
        'select *, cast(d1 as char) as d4, cast(d2 as char) as d5, cast(d3 as char) as d6 from t',
        (err, _rows) => {
          if (err) return reject(err);
          rows7 = _rows;
          checkDone();
        }
      );
    });

    const connBadTz = createConnection({ timezone: 'utc' });
    strict.equal(connBadTz.config.timezone, 'Z');
    connBadTz.end();

    // local TZ
    strict.equal(rows[0].t.constructor, Date);
    strict.equal(rows[0].t.getDate(), date.getDate());
    strict.equal(rows[0].t.getHours(), date.getHours());
    strict.equal(rows[0].t.getMinutes(), date.getMinutes());
    strict.equal(rows[0].t.getSeconds(), date.getSeconds());

    // UTC
    strict.equal(rowsZ[0].t.constructor, Date);
    strict.equal(rowsZ[0].t.getDate(), date.getDate());
    strict.equal(rowsZ[0].t.getHours(), date.getHours());
    strict.equal(rowsZ[0].t.getMinutes(), date.getMinutes());
    strict.equal(rowsZ[0].t.getSeconds(), date.getSeconds());

    // +09:30
    strict.equal(rows0930[0].t.constructor, Date);
    strict.equal(rows0930[0].t.getDate(), date.getDate());
    strict.equal(rows0930[0].t.getHours(), date.getHours());
    strict.equal(rows0930[0].t.getMinutes(), date.getMinutes());
    strict.equal(rows0930[0].t.getSeconds(), date.getSeconds());

    // local TZ
    strict.equal(rows1[0].t.constructor, Date);
    strict.equal(
      rows1[0].t.getTime(),
      new Date('Mon Jan 01 1990 00:00:00 UTC').getTime()
    );

    // UTC
    strict.equal(rows1Z[0].t.constructor, Date);
    strict.equal(
      rows1Z[0].t.getTime(),
      new Date('Mon Jan 01 1990 00:00:00 UTC').getTime()
    );

    // +09:30
    strict.equal(rows10930[0].t.constructor, Date);
    strict.equal(
      rows10930[0].t.getTime(),
      new Date('Mon Jan 01 1990 00:00:00 UTC').getTime()
    );

    // local TZ
    strict.equal(rows2[0].d1.getTime(), toMidnight(date).getTime());
    strict.equal(rows2[0].d2.getTime(), datetime.getTime());
    strict.equal(rows2[0].d3.getTime(), datetime.getTime());
    strict.equal(rows2[0].d4, formatUTCDate(adjustTZ(date)));
    strict.equal(rows2[0].d5, formatUTCDateTime(adjustTZ(datetime), 3));
    strict.equal(rows2[0].d6, formatUTCDateTime(adjustTZ(datetime), 6));

    // UTC
    strict.equal(rows3[0].d1.getTime(), toMidnight(date, 0).getTime());
    strict.equal(rows3[0].d2.getTime(), datetime.getTime());
    strict.equal(rows3[0].d3.getTime(), datetime.getTime());
    strict.equal(rows3[0].d4, formatUTCDate(date));
    strict.equal(rows3[0].d5, formatUTCDateTime(datetime, 3));
    strict.equal(rows3[0].d6, formatUTCDateTime(datetime, 6));

    // dateStrings
    strict.deepEqual(rows4, dateAsStringExpected);
    strict.deepEqual(rows5, dateAsStringExpected);
    strict.equal(rows6.length, 1);

    // dateStrings as array
    strict.equal(rows8[0].d1, '1990-01-01');
    strict.equal(rows8[0].d1.constructor, String);
    strict.equal(rows8[0].d2.constructor, Date);
    strict.equal(rows8[0].d3.constructor, Date);
    strict.equal(rows8[0].d4, null);
    strict.equal(rows8[0].d5.constructor, Date);
    strict.equal(rows8[0].d6.constructor, Date);

    // +09:30
    const tzOffset = -570;
    strict.equal(rows7[0].d1.getTime(), toMidnight(date, tzOffset).getTime());
    strict.equal(rows7[0].d2.getTime(), datetime.getTime());
    strict.equal(rows7[0].d3.getTime(), datetime.getTime());
    strict.equal(rows7[0].d4, formatUTCDate(adjustTZ(date, tzOffset)));
    strict.equal(
      rows7[0].d5,
      formatUTCDateTime(adjustTZ(datetime, tzOffset), 3)
    );
    strict.equal(
      rows7[0].d6,
      formatUTCDateTime(adjustTZ(datetime, tzOffset), 6)
    );
  });

  connection.end();
  connection1.end();
  connection2.end();
  connectionZ.end();
  connection0930.end();
});
