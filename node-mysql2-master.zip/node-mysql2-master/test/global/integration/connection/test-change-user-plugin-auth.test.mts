import type { RowDataPacket } from '../../../../index.js';
import { Buffer } from 'node:buffer';
import process from 'node:process';
import { describe, it, skip, strict } from 'poku';
import { createConnection } from '../../../common.test.mjs';

if (`${process.env.MYSQL_CONNECTION_URL}`.includes('pscale_pw_')) {
  skip('Skipping test for PlanetScale');
}

await describe('Change User Plugin Auth', async () => {
  const connection = createConnection();
  const onlyUsername = function (name: string) {
    return name.substring(0, name.indexOf('@'));
  };

  connection.query(
    "CREATE USER IF NOT EXISTS 'changeuser1'@'%' IDENTIFIED BY 'changeuser1pass'"
  );
  connection.query(
    "CREATE USER IF NOT EXISTS 'changeuser2'@'%' IDENTIFIED BY 'changeuser2pass'"
  );
  connection.query("GRANT SELECT ON *.* TO 'changeuser1'@'%'");
  connection.query("GRANT SELECT ON *.* TO 'changeuser2'@'%'");
  connection.query('FLUSH PRIVILEGES');

  await it('should switch users and verify current_user()', async () => {
    await new Promise<void>((resolve, reject) => {
      connection.changeUser(
        { user: 'changeuser1', password: 'changeuser1pass' },
        (err) => (err ? reject(err) : resolve())
      );
    });

    const rows1 = await new Promise<RowDataPacket[]>((resolve, reject) => {
      connection.query<RowDataPacket[]>('select current_user()', (err, rows) =>
        err ? reject(err) : resolve(rows)
      );
    });
    strict.deepEqual(onlyUsername(rows1[0]['current_user()']), 'changeuser1');

    await new Promise<void>((resolve, reject) => {
      connection.changeUser(
        { user: 'changeuser2', password: 'changeuser2pass' },
        (err) => (err ? reject(err) : resolve())
      );
    });

    const rows2 = await new Promise<RowDataPacket[]>((resolve, reject) => {
      connection.query<RowDataPacket[]>('select current_user()', (err, rows) =>
        err ? reject(err) : resolve(rows)
      );
    });
    strict.deepEqual(onlyUsername(rows2[0]['current_user()']), 'changeuser2');

    await new Promise<void>((resolve, reject) => {
      connection.changeUser(
        {
          user: 'changeuser1',
          password: 'changeuser1pass',
          // @ts-expect-error: TODO: implement typings
          passwordSha1: Buffer.from(
            'f961d39c82138dcec42b8d0dcb3e40a14fb7e8cd',
            'hex'
          ), // sha1(changeuser1pass)
        },
        (err) => (err ? reject(err) : resolve())
      );
    });

    const rows3 = await new Promise<RowDataPacket[]>((resolve, reject) => {
      connection.query<RowDataPacket[]>('select current_user()', (err, rows) =>
        err ? reject(err) : resolve(rows)
      );
    });
    strict.deepEqual(onlyUsername(rows3[0]['current_user()']), 'changeuser1');
  });

  connection.end();

  // Use a fresh root connection to cleanup
  const cleanup = createConnection().promise();
  await cleanup.query("DROP USER IF EXISTS 'changeuser1'@'%'");
  await cleanup.query("DROP USER IF EXISTS 'changeuser2'@'%'");
  await cleanup.end();
});
