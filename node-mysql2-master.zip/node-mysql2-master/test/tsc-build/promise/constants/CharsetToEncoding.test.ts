import { mysqlp as mysql } from '../../index.test.js';

const charsetToEncoding: string[] = mysql.CharsetToEncoding;
const utf8: string = charsetToEncoding[0];
