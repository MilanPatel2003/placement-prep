import { mysqlp as mysql } from '../../index.test.js';

const BIG5_CHINESE_CI: number = mysql.Charsets.BIG5_CHINESE_CI;
const BIG5: number = mysql.Charsets.BIG5;
