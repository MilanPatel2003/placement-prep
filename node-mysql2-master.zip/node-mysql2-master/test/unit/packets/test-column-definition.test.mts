import { describe, it, strict } from 'poku';
import ColumnDefinition from '../../../lib/packets/column_definition.js';

const sequenceId = 5;

describe('ColumnDefinition', () => {
  it('should serialize simple column definition', () => {
    const packet = ColumnDefinition.toPacket(
      {
        catalog: 'def',
        schema: 'some_db',
        name: 'some_col',
        orgName: 'some_col',
        table: 'some_tbl',
        orgTable: 'some_tbl',

        characterSet: 0x21,
        columnLength: 500,
        flags: 32896,
        columnType: 0x8,
        decimals: 1,
      },
      sequenceId
    );
    strict.equal(
      packet.buffer.toString('hex', 4),
      '0364656607736f6d655f646208736f6d655f74626c08736f6d655f74626c08736f6d655f636f6c08736f6d655f636f6c0c2100f4010000088080010000'
    );
  });

  it('should serialize Russian (unicode) column definition', () => {
    const packet = ColumnDefinition.toPacket(
      {
        catalog: 'def',
        schema: 's_погоди',
        name: 'n_погоди',
        orgName: 'on_погоди',
        table: 't_погоди',
        orgTable: 'ot_погоди',
        characterSet: 0x21,
        columnLength: 500,
        flags: 32896,
        columnType: 0x8,
        decimals: 1,
      },
      sequenceId
    );
    strict.equal(
      packet.buffer.toString('hex', 4),
      '036465660e735fd0bfd0bed0b3d0bed0b4d0b80e745fd0bfd0bed0b3d0bed0b4d0b80f6f745fd0bfd0bed0b3d0bed0b4d0b80e6e5fd0bfd0bed0b3d0bed0b4d0b80f6f6e5fd0bfd0bed0b3d0bed0b4d0b80c2100f4010000088080010000'
    );
  });

  // Spec (from example: https://dev.mysql.com/doc/internals/en/protocoltext-resultset.html)
  it('should serialize and deserialize spec example', () => {
    const inputColDef = {
      catalog: 'def',
      schema: '',
      name: '@@version_comment',
      orgName: '',
      table: '',
      orgTable: '',

      characterSet: 0x08, // latin1_swedish_ci
      columnLength: 0x1c,
      flags: 0,
      columnType: 0xfd,
      type: 0xfd,
      encoding: 'latin1',
      decimals: 0x1f,
    };
    const packet = ColumnDefinition.toPacket(inputColDef, sequenceId);
    strict.equal(
      packet.buffer.toString('hex', 4),
      '0364656600000011404076657273696f6e5f636f6d6d656e74000c08001c000000fd00001f0000'
    );

    packet.offset = 4;
    const colDef = new ColumnDefinition(packet, 'utf8');
    // inspect omits the "colulumnType" property because type is an alias for it
    // but ColumnDefinition.toPacket reads type from "columnType"
    // TODO: think how to make this more consistent
    const inspect = { columnType: 253, ...colDef.inspect() };
    strict.deepEqual(inspect, inputColDef);
    strict.equal(colDef.db, inputColDef.schema);
  });
});
